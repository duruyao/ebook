abstract class Button {
  void paint();
}
