import 'button.dart';

class MacOSButton implements Button {
  @override
  void paint() {
    print('You have created MacOSButton.');
  }
}
