import 'button.dart';

class WindowsButton implements Button {
  @override
  void paint() {
    print('You have created WindowsButton.');
  }
}
