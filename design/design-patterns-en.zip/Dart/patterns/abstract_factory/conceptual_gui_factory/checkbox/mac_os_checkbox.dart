import 'checkbox.dart';

class MacOSCheckbox implements Checkbox {
  @override
  void paint() {
    print('You have created MacOSCheckbox.');
  }
}
