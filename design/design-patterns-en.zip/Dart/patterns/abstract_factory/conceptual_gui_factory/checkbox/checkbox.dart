abstract class Checkbox {
  void paint();
}
