import 'checkbox.dart';

class WindowsCheckbox implements Checkbox {
  @override
  void paint() {
    print('You have created WindowsCheckbox.');
  }
}
