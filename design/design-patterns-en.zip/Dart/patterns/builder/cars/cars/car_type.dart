enum CarType {
  cityCar,
  sportCar,
  suv,
}
