/// EN: Just another feature of a car.
///
/// RU: Одна из фишек автомобиля.
enum Transmission {
  singleSpeed,
  manual,
  automatic,
  semiAutomatic,
}
