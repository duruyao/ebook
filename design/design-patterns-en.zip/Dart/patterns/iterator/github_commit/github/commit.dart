class Commit {
  String message;

  Commit(this.message);
}
