class One {
  final String param1 = '1';
}

class Two {
  final String param2 = '2';
}

class Three {
  final String param3 = '3';
}
