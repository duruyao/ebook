part of mediator;

class Component {
  get mediator => _mediator;

  Mediator? _mediator;
}
