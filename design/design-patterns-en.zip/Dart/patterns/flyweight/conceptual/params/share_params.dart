class ShareParams {
  final int param1;
  final String param2;
  final double param3;

  ShareParams(this.param1, this.param2, this.param3);
}
