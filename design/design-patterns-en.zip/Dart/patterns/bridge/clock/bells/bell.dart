abstract class Bell {
  void ring();

  void notify(String message);
}
