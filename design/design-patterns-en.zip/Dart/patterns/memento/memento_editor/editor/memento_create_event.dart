import '../../../observer/app_observer/observer/event.dart';

class MementoCreateEvent extends Event {}
