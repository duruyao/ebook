typedef Snapshot = String;
