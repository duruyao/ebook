
import 'snapshot.dart';

class Memento {
  final DateTime time;
  final Snapshot snapshot;

  Memento(this.time, this.snapshot);
}
