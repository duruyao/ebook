import 'codec.dart';

class MPEG4CompressionCodec implements Codec {
  String type = 'mp4';
}
