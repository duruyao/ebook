import 'dart:io';

import 'video_file.dart';

class AudioMixer {
  File fix(VideoFile result) {
    print('AudioMixer: fixing audio...');
    return File('tmp');
  }
}
