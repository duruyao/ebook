import 'codec.dart';

class OggCompressionCodec implements Codec {
  final type = 'ogg';
}
