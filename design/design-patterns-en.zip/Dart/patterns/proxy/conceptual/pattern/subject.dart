abstract class Subject {
  String request();
}
