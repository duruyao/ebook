import '../../../observer/app_observer/observer/event.dart';

class RepaintEvent extends Event {}
