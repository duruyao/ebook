abstract class RepaintCompatible {
  void repaint();
}
