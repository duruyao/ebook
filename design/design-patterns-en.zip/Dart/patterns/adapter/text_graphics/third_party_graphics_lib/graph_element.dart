import 'dart:typed_data';

abstract class GraphElement {
  Int32List get points;
}
