abstract class DataSource {
  void writeData(String data);

  String readData();
}
