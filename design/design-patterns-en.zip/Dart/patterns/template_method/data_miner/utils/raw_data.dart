typedef RawData = String;
typedef StringTable = List<List<String>>;
