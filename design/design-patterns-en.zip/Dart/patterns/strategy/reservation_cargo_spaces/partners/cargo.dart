class Cargo {
  final double size;

  Cargo(this.size);
}
