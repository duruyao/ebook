class OrderConfirmationSequence {
  var _index = 0;

  int next() => _index++;
}
