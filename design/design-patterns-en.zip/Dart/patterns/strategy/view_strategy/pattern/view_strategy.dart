import 'byte_context.dart';

abstract class ViewStrategy {
  String out(ByteContext byteList);
}
