package main

type VeggeMania struct {
}

func (p *VeggeMania) getPrice() int {
	return 15
}
